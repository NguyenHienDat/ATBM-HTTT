﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PH2_ATBM
{
    public partial class AnnouncementForm : Form
    {
        public AnnouncementForm(string username, string password)
        {
            InitializeComponent();
            getAnnouncement();
        }

        private void getAnnouncement()
        {
            
            if ((LoginForm.conn.State & ConnectionState.Open) > 0)
            {
               
                    using (OracleCommand cmd = new OracleCommand("select * from admin_ols.thongbao", LoginForm.conn))
                    {
                        cmd.CommandType = CommandType.Text;
        

                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            DataTable dataTable = new DataTable();
                            dataTable.Load(reader);
                       
                            dataGridView1.DataSource = dataTable;
                            
                        }
                    }
                }
            }
    }
}
