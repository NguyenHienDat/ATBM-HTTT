﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace PH2_ATBM
{
    public partial class MainForm : Form
    {
        string user_name;
        string pwd;
        string vaitro;
        string connstr;
        string curTab;
        LoginForm loginForm = null;
        string[] tables = {"NHANSU", "SINHVIEN", "DONVI", "HOCPHAN", "KHMO", "PHANCONG", "DANGKY"};
        public MainForm(string username, string password, LoginForm lg)
        {
            InitializeComponent();
            user_name = username;
            pwd = password;
            this.Size = new Size(1280, 720);
            connstr = $"USER ID={username};PASSWORD={password};DATA SOURCE=localhost:1521/PDBProject";
            string dba = ";DBA PRIVILEGE=SYSDBA";
            if (username == "sys" || password == "SYS") connstr += dba;
            label14.Text = $"Welcome {username}";
            getVaiTro();
            loginForm = lg;
            this.FormClosed += MainForm_FormClosed;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click_1(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click_2(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            AnnouncementForm tb = new AnnouncementForm(user_name, pwd);
            tb.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
             this.Close();
           
        }
        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
           
              loginForm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int tab_idx = TabControl1.SelectedIndex;
            curTab = TabControl1.TabPages[tab_idx].Text;
            using (OracleConnection con = new OracleConnection(connstr))
            {
                try
                {
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                        if (vaitro != "Sinh vien")
                        {
                            using (OracleCommand cmd = new OracleCommand("sys.get_table", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("table_idx", OracleDbType.Int32).Value = tab_idx;

                                cmd.Parameters.Add("p_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;
                                cmd.Parameters.Add("vaitro", OracleDbType.Varchar2).Value = vaitro;

                                using (OracleDataReader reader = cmd.ExecuteReader())
                                {
                                    DataTable dataTable = new DataTable();
                                    dataTable.Load(reader);
                                    if (tab_idx == 0)
                                        dataGridView1.DataSource = dataTable;
                                    else if (tab_idx == 1)
                                        dataGridView2.DataSource = dataTable;
                                    else if (tab_idx == 2)
                                        dataGridView3.DataSource = dataTable;
                                    else if (tab_idx == 3)
                                        dataGridView4.DataSource = dataTable;
                                    else if (tab_idx == 4)
                                        dataGridView5.DataSource = dataTable;
                                    else if (tab_idx == 5)
                                        dataGridView6.DataSource = dataTable;
                                    else if (tab_idx == 6)
                                        dataGridView7.DataSource = dataTable;
                                }
                            }
                        }
                        else
                        {
                            string query = "select * from ATBM." + tables[tab_idx];


                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {
                                cmd.CommandType = CommandType.Text;
                                
                                using (OracleDataReader reader = cmd.ExecuteReader())
                                {
                                    DataTable dataTable = new DataTable();
                                    dataTable.Load(reader);
                                    if (tab_idx == 0)
                                        dataGridView1.DataSource = dataTable;
                                    else if (tab_idx == 1)
                                        dataGridView2.DataSource = dataTable;
                                    else if (tab_idx == 2)
                                        dataGridView3.DataSource = dataTable;
                                    else if (tab_idx == 3)
                                        dataGridView4.DataSource = dataTable;
                                    else if (tab_idx == 4)
                                        dataGridView5.DataSource = dataTable;
                                    else if (tab_idx == 5)
                                        dataGridView6.DataSource = dataTable;
                                    else if (tab_idx == 6)
                                        dataGridView7.DataSource = dataTable;
                                }
                            }
                        }
                       

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void tcDangKy_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label34_Click(object sender, EventArgs e)
        {

        }

        private void tcKHMO_Click(object sender, EventArgs e)
        {

        }

        private void textBox41_TextChanged(object sender, EventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void getVaiTro()
        {
            using (OracleConnection con = new OracleConnection(connstr))
            {
                try
                {
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                        if (user_name[0] == 'N')
                        {
                            using (OracleCommand command = new OracleCommand($"SELECT VAITRO FROM ATBM.NHANSU WHERE MANV = '{user_name}'", con))
                            {
                                object result = command.ExecuteScalar();

                                // Check if the result is not null
                                if (result != null)
                                {
                                    // Convert the result to string and assign it to the vaitro variable
                                    vaitro = result.ToString();
                                    label14.Text += $"- {vaitro}";
                                }

                            }
                        
                        }
                        else if (user_name[0] == 'S' && user_name != "SYS")
                        {
                            vaitro = "Sinh vien";
                            label14.Text += $"- {vaitro}";

                        }


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void textBoxlimit(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            int tab_idx = TabControl1.SelectedIndex;
            using (OracleConnection con = new OracleConnection(connstr))
            {
                 
                try
                {
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                        if (tab_idx == 0)
                        {
                            if (vaitro != "Truong khoa")
                            using (OracleCommand cmd = new OracleCommand("sys.update_NHANSU", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("sdt", OracleDbType.Varchar2).Value = textBox17.Text;
                                /*        cmd.Parameters.Add("mnv", OracleDbType.Varchar2).Value = user_name;*/
                                cmd.ExecuteNonQuery();
                            }
                            else if (vaitro == "Truong khoa")
                            {
                                using (OracleCommand cmd = new OracleCommand("sys.p_edit_nhansu_tk", con))
                                {
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.Add("p_manv", OracleDbType.Varchar2).Value = textBox11.Text;
                                    cmd.Parameters.Add("p_hoten", OracleDbType.Varchar2).Value = textBox12.Text;
                                    cmd.Parameters.Add("p_phai", OracleDbType.Varchar2).Value = textBox13.Text;
                                    cmd.Parameters.Add("p_ngsinh", OracleDbType.Varchar2).Value = textBox15.Text;
                                    cmd.Parameters.Add("p_phucap", OracleDbType.Varchar2).Value = textBox16.Text;
                                    cmd.Parameters.Add("p_dt", OracleDbType.Varchar2).Value = textBox17.Text;
                                    cmd.Parameters.Add("p_vaitro", OracleDbType.Varchar2).Value = textBox18.Text;
                                    cmd.Parameters.Add("p_madv", OracleDbType.Varchar2).Value = textBox19.Text;
                                

                                    cmd.Parameters.Add("p_mode", OracleDbType.Int32).Value = 1;

                                    cmd.ExecuteNonQuery();
                                }
                            }
                           

                        }
                        else if (tab_idx == 6)
                        {
                            using (OracleCommand cmd = new OracleCommand("sys.p_update_gv_DANGKY", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("p_diemth", OracleDbType.Decimal).Value = textBox7.Text;
                                cmd.Parameters.Add("p_diemqt", OracleDbType.Decimal).Value = textBox8.Text;
                                cmd.Parameters.Add("p_diemck", OracleDbType.Decimal).Value = textBox9.Text;
                                cmd.Parameters.Add("p_diemtk", OracleDbType.Decimal).Value = textBox10.Text;
                                cmd.Parameters.Add("p_masv", OracleDbType.Varchar2).Value = textBox2.Text;
                                cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = textBox4.Text;
                                cmd.Parameters.Add("p_hk", OracleDbType.Varchar2).Value = textBox1.Text;
                                cmd.Parameters.Add("p_nam", OracleDbType.Varchar2).Value = textBox5.Text;
                                cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = textBox6.Text;
                   
                                /*        cmd.Parameters.Add("mnv", OracleDbType.Varchar2).Value = user_name;*/
                                cmd.ExecuteNonQuery();
                            }
                        }
                        else if (tab_idx == 5)
                        {
                            string proc = "sys.p_edit_phancong";
                            if (vaitro == "Truong khoa") proc = "sys.p_edit_phancong_tk";
                            if (vaitro == "Giao vu") proc = $"update ATBM.PHANCONG set  MAGV = '{textBox14.Text}' where HK = '{textBox48.Text}' and NAM = '{textBox47.Text}' and MACT = '{textBox50.Text}' and MAGV = '{textBox45.Text}'  and MAHP = '{textBox46.Text}'";
                                using (OracleCommand cmd = new OracleCommand(proc, con))
                            {
                                if (vaitro != "Giao vu")
                                {
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.Add("p_magv", OracleDbType.Varchar2).Value = textBox45.Text;
                                    cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = textBox46.Text;
                                    cmd.Parameters.Add("p_hk", OracleDbType.Varchar2).Value = textBox48.Text;
                                    cmd.Parameters.Add("p_nam", OracleDbType.Varchar2).Value = textBox47.Text;
                                    cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = textBox50.Text;
                                    cmd.Parameters.Add("p_mode", OracleDbType.Int32).Value = 1;
                                    if (vaitro == "Truong khoa")
                                        cmd.Parameters.Add("new_gv", OracleDbType.Varchar2).Value = textBox14.Text;
                                }
                                
   
                                cmd.ExecuteNonQuery();
                            }
                            
                           
                            

                        }
                        else if (tab_idx == 1 && vaitro != "Giao vu")
                        {
                            if (vaitro == "Sinh vien")
                            {
                                using (OracleCommand cmd = new OracleCommand($"UPDATE ATBM.SINHVIEN SET DIACHI = '{textBox25.Text}', DT = '{textBox24.Text}' WHERE MASV = '{user_name}'", con))
                                {
                                 
                                    cmd.ExecuteNonQuery();
                                }
                            }
                        }
                        else if (tab_idx == 1 && vaitro == "Giao vu")
                        {
                            string query = $"UPDATE ATBM.SINHVIEN SET HOTEN = '{textBox22.Text}', PHAI = '{textBox23.Text}', NGSINH = TO_DATE('{textBox26.Text}', 'DD-MM-YYYY'), DIACHI = '{textBox25.Text}', DT = '{textBox24.Text}', MACT = '{textBox29.Text}', MANGANH = '{textBox28.Text}', SOTCTL = '{textBox27.Text}', DTBTL = '{textBox32.Text}' WHERE MASV = '{textBox21.Text}'";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }
                        else if (tab_idx == 2 && vaitro == "Giao vu")
                        {
                            string query = $"UPDATE ATBM.DONVI SET TENDV = '{textBox31.Text}', TRGDV = '{textBox33.Text}' where MADV = '{textBox30.Text}'";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }

                        else if (tab_idx == 3 && vaitro == "Giao vu")
                        {
                            string query = $"UPDATE ATBM.HOCPHAN SET TENHP = '{textBox35.Text}', SOTC = '{textBox36.Text}', STLT ='{textBox37.Text}', STTH = '{textBox38.Text}', SOSVTD ='{textBox39.Text}', MADV = '{textBox40.Text}' where MAHP = '{textBox34.Text}'";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int tab_idx = TabControl1.SelectedIndex;
            using (OracleConnection con = new OracleConnection(connstr))
            {

                try
                {
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                        if (tab_idx == 5)
                        {
                            string proc = "sys.p_edit_phancong";
                            if (vaitro == "Truong khoa") proc = "sys.p_edit_phancong_tk";
                            using (OracleCommand cmd = new OracleCommand(proc, con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("p_magv", OracleDbType.Varchar2).Value = textBox45.Text;
                                cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = textBox46.Text;
                                cmd.Parameters.Add("p_hk", OracleDbType.Varchar2).Value = textBox48.Text;
                                cmd.Parameters.Add("p_nam", OracleDbType.Varchar2).Value = textBox47.Text;
                                cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = textBox50.Text;
                                cmd.Parameters.Add("p_mode", OracleDbType.Int32).Value = 0;
                                if (vaitro == "Truong khoa")
                                    cmd.Parameters.Add("new_gv", OracleDbType.Varchar2).Value = textBox14.Text;
                                cmd.ExecuteNonQuery();
                            }

                        }
                        if (tab_idx == 0 && vaitro == "Truong khoa")
                        {
                            using (OracleCommand cmd = new OracleCommand("sys.p_edit_nhansu_tk", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("p_manv", OracleDbType.Varchar2).Value = textBox11.Text;
                                cmd.Parameters.Add("p_hoten", OracleDbType.Varchar2).Value = textBox12.Text;
                                cmd.Parameters.Add("p_phai", OracleDbType.Varchar2).Value = textBox13.Text;
                                cmd.Parameters.Add("p_ngsinh", OracleDbType.Varchar2).Value = textBox15.Text;
                                cmd.Parameters.Add("p_phucap", OracleDbType.Varchar2).Value = textBox16.Text;
                                cmd.Parameters.Add("p_dt", OracleDbType.Varchar2).Value = textBox17.Text;
                                cmd.Parameters.Add("p_vaitro", OracleDbType.Varchar2).Value = textBox18.Text;
                                cmd.Parameters.Add("p_madv", OracleDbType.Varchar2).Value = textBox19 .Text;

                                cmd.Parameters.Add("p_mode", OracleDbType.Int32).Value = 0;

                                cmd.ExecuteNonQuery();
                            }
                        }
                        

                        if (tab_idx == 6 && vaitro == "Giao vu")
                        {
                            string query = $"INSERT INTO ATBM.DANGKY VALUES('{textBox2.Text}', '{textBox3.Text}', '{textBox4.Text}', '{textBox1.Text}', '{textBox5.Text}', '{textBox6.Text}', '{textBox7.Text}', '{textBox8.Text}', '{textBox9.Text}', '{textBox10.Text}')";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }

                        if (tab_idx == 1 && vaitro == "Giao vu")
                        {
                            string query = $"INSERT INTO ATBM.SINHVIEN VALUES('{textBox21.Text}', '{textBox22.Text}', '{textBox23.Text}', '{textBox26.Text}', '{textBox25.Text}', '{textBox24.Text}', '{textBox29.Text}', '{textBox28.Text}', '{textBox27.Text}', '{textBox32.Text}')";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }
                        if (tab_idx == 2 && vaitro == "Giao vu")
                        {
                            string query = $"INSERT INTO ATBM.DONVI VALUES('{textBox30.Text}', '{textBox31.Text}', '{textBox33.Text}')";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }

                        if (tab_idx == 3 && vaitro == "Giao vu")
                        {
                            string query = $"INSERT INTO ATBM.HOCPHAN(MAHP, TENHP, SOTC, STLT, STTH, SOSVTD, MADV) VALUES('{textBox34.Text}', '{textBox35.Text}', '{textBox36.Text}', '{textBox37.Text}', '{textBox38.Text}', '{textBox39.Text}', '{textBox40.Text}')";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int tab_idx = TabControl1.SelectedIndex;
            using (OracleConnection con = new OracleConnection(connstr))
            {

                try
                {
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                        string proc = "sys.p_edit_phancong";
                        if (vaitro == "Truong khoa") proc = "sys.p_edit_phancong_tk";
                        if (tab_idx == 5)
                        {
                            using (OracleCommand cmd = new OracleCommand(proc, con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("p_magv", OracleDbType.Varchar2).Value = textBox45.Text;
                                cmd.Parameters.Add("p_mahp", OracleDbType.Varchar2).Value = textBox46.Text;
                                cmd.Parameters.Add("p_hk", OracleDbType.Varchar2).Value = textBox48.Text;
                                cmd.Parameters.Add("p_nam", OracleDbType.Varchar2).Value = textBox47.Text;
                                cmd.Parameters.Add("p_mact", OracleDbType.Varchar2).Value = textBox50.Text;
                                cmd.Parameters.Add("p_mode", OracleDbType.Int32).Value = 2;
                                if (vaitro == "Truong khoa")
                                    cmd.Parameters.Add("new_gv", OracleDbType.Varchar2).Value = textBox14.Text;
                                cmd.ExecuteNonQuery();
                            }

                        }
                        if (tab_idx == 0 && vaitro == "Truong khoa")
                        {
                            using (OracleCommand cmd = new OracleCommand("sys.p_edit_nhansu_tk", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("p_manv", OracleDbType.Varchar2).Value = textBox11.Text;
                                cmd.Parameters.Add("p_hoten", OracleDbType.Varchar2).Value = textBox12.Text;
                                cmd.Parameters.Add("p_phai", OracleDbType.Varchar2).Value = textBox13.Text;
                                cmd.Parameters.Add("p_ngsinh", OracleDbType.Varchar2).Value = textBox15.Text;
                                cmd.Parameters.Add("p_phucap", OracleDbType.Varchar2).Value = textBox16.Text;
                                cmd.Parameters.Add("p_dt", OracleDbType.Varchar2).Value = textBox17.Text;
                                cmd.Parameters.Add("p_vaitro", OracleDbType.Varchar2).Value = textBox18.Text;
                                cmd.Parameters.Add("p_madv", OracleDbType.Varchar2).Value = textBox19.Text;
                                cmd.Parameters.Add("p_mode", OracleDbType.Int32).Value = 2;

                                cmd.ExecuteNonQuery();
                            }
                        }
                        if (tab_idx == 6 && vaitro == "Giao vu")
                        {
                            string query = $"DELETE FROM ATBM.DANGKY WHERE MASV = '{textBox2.Text}' and MAHP = '{textBox4.Text}' and NAM = '{textBox5.Text}' and HK = '{textBox1.Text}'";
                            using (OracleCommand cmd = new OracleCommand(query, con))
                            {

                                cmd.ExecuteNonQuery();
                            }
                        }


                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            
            using (OracleConnection con = new OracleConnection(connstr))
            {
                try
                {
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                       if (vaitro == "Giao vu")
                        {
                            using (OracleCommand cmd = new OracleCommand("sys.p_searchsv_gv", con))
                            {
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.Parameters.Add("p_masv", OracleDbType.Varchar2).Value = textBox20.Text;

                                cmd.Parameters.Add("p_cursor", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                                using (OracleDataReader reader = cmd.ExecuteReader())
                                {
                                    DataTable dataTable = new DataTable();
                                    dataTable.Load(reader);
                                 
                                    dataGridView7.DataSource = dataTable;
                                }
                            }
                        }

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }
    }
}
