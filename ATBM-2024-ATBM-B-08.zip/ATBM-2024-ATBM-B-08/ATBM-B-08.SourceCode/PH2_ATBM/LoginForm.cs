﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using ATBM_Project;

namespace PH2_ATBM
{
    public partial class LoginForm : Form
    {
        string connstr;
        public static OracleConnection conn;
        public LoginForm()
        {
            InitializeComponent();
            comboBox1.Items.Add("Phân hệ 1");
            comboBox1.Items.Add("Phân hệ 2");
            txtPassword.PasswordChar = '*';

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            connstr = $"USER ID={txtUsername.Text};PASSWORD={txtPassword.Text};DATA SOURCE=localhost:1521/PDBProject";
            string dba = ";DBA PRIVILEGE=SYSDBA";
            if (txtUsername.Text == "sys" || txtUsername.Text == "SYS") connstr += dba;
            conn = new OracleConnection(connstr);
            conn.Open();
            using (OracleConnection con = new OracleConnection(connstr))
            {
                
                    con.Open();
                    if ((con.State & ConnectionState.Open) > 0)
                    {
                        MessageBox.Show("Đăng Nhập Thành Công");
                        con.Close();
                    string selectedText = comboBox1.SelectedItem.ToString();
                    if (selectedText == "Phân hệ 1")
                        {
                            MainForm_ph1 ph1 = new MainForm_ph1();
                            this.Hide();
                            ph1.ShowDialog();
                        
                        }
                     else if (selectedText == "Phân hệ 2")
                     {
                        if (txtUsername.Text == "SYS" || txtUsername.Text == "sys" || txtUsername.Text == "ATBM")
                        {
                            Audit audit = new Audit(this);
                            this.Hide();
                            audit.ShowDialog();
                        }
                        else
                        {
                            MainForm mainForm = new MainForm(txtUsername.Text, txtPassword.Text, this);
                            this.Hide();
                            mainForm.ShowDialog();
                        }    
                            
                     }
                        
                    }
                    else
                    {
                        MessageBox.Show("Đăng Nhập Thất Bại 1");
                    }
                
                /*catch
                {
                    MessageBox.Show("Đăng Nhập Thất Bại 2");
                }
                finally
                {
                    con.Close();
                }*/
            }
        }
    }
}
