﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using ATBM_Project;

namespace PH2_ATBM
{
    public partial class Audit : Form
    {
        LoginForm loginForm = null;
        public Audit(LoginForm lg)
        {
            InitializeComponent();
            this.Size = new Size(1280, 720);
            loadData();
            loginForm = lg;
            this.FormClosed += MainForm_FormClosed;
        }

        private void loadData()
        {
      
            using (OracleCommand cmd = new OracleCommand("select * from UNIFIED_AUDIT_TRAIL where AUDIT_TYPE = 'FineGrainedAudit'", LoginForm.conn))
            {
                cmd.CommandType = CommandType.Text;

                using (OracleDataReader reader = cmd.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);
                    
                    dataGridView1.DataSource = dataTable;
                    
                       
                }
            }

            using (OracleCommand cmd = new OracleCommand("select * from UNIFIED_AUDIT_TRAIL where AUDIT_TYPE = 'Standard'", LoginForm.conn))
            {
                cmd.CommandType = CommandType.Text;

                using (OracleDataReader reader = cmd.ExecuteReader())
                {
                    DataTable dataTable = new DataTable();
                    dataTable.Load(reader);

                    dataGridView2.DataSource = dataTable;


                }
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {

            loginForm.Show();
        }
    }
}
