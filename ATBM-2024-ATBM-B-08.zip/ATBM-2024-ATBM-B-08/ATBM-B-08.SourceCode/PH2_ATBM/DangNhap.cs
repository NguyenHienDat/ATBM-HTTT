﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;


namespace ATBM_Project
{
    public partial class DangNhap : Form
    {
        public static OracleConnection conn;
        public string connectionString;
        public DangNhap()
        {
            InitializeComponent();
            this.FormClosed += CloseForm;
            textBox2.PasswordChar = '*';
        }
        private void button1_Click(object sender, EventArgs e)
        {
            connectionString = $@"USER ID={textBox1.Text};PASSWORD={textBox2.Text};DATA SOURCE=localhost:1521/PDBProject;DBA Privilege=SYSDBA";

            conn = new OracleConnection(connectionString);
            try
            {
                conn.Open();
                if (conn.State == ConnectionState.Open)
                {
                    
                    MainForm_ph1 mainForm = new MainForm_ph1();
                    this.Hide();
                    mainForm.Show();
                   

                }
                
            }
            catch (OracleException ex)
            {
                MessageBox.Show("Failed to connect: " + ex.Message);
            }
        }
        private void CloseForm(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
            DangNhap.conn.Close();
        }


    }
}
